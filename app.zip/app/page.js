"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import K from './components/k';

// --- ICONS (No changes) ---



// --- END ICONS ---

// Hardcoded "correct" IDs for the dummy login
const VALID_IDS = {
  POLICE: "BKP001",
  TOURISM: "TWB01",
};

// Predefined locations for the dropdown
const LOCATION_OPTIONS = {
    police: ['Barrackpore Division', 'Kolkata North Division', 'Howrah City Police'],
    tourism: ['Kolkata Head Office', 'Darjeeling District Office', 'Siliguri Regional Office'],
};

export default function LandingPage() {
  const router = useRouter();
  const [loginType, setLoginType] = useState('police'); // 'police' or 'tourism'
  const [formData, setFormData] = useState({ name: '', id: '', location: LOCATION_OPTIONS.police[0] });
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleTabChange = (type) => {
    setLoginType(type);
    setError(''); // Reset error on tab switch
    // Reset form fields and set location to the first available option
    setFormData({
      name: '',
      id: '',
      location: LOCATION_OPTIONS[type][0],
    });
  };

  const handleLogin = (e) => {
    e.preventDefault();
    setError('');

    if (!formData.name || !formData.id || !formData.location) {
      setError('All fields are required.');
      return;
    }

    const idToValidate = formData.id.trim().toUpperCase();
    let isValid = false;

    if (loginType === 'police') {
      isValid = idToValidate === VALID_IDS.POLICE;
    } else {
      isValid = idToValidate === VALID_IDS.TOURISM;
    }

    if (isValid) {
      // For now, both logins redirect to the police dashboard.
      router.push('/police');
    } else {
      setError('Invalid ID. Please try again.');
    }
  };
  
  // Dynamic form labels and placeholders based on loginType
  const formConfig = {
    police: {
      nameLabel: 'DGP Name',
      namePlaceholder: 'e.g., Alok Sharma',
      idLabel: 'Police ID',
      idPlaceholder: 'Enter official ID (Hint: BKP001)',
      locationLabel: 'Station / Division',
    },
    tourism: {
      nameLabel: 'Head of Dept. Name',
      namePlaceholder: 'e.g., Priya Roy',
      idLabel: 'Department ID',
      idPlaceholder: 'Enter official ID (Hint: TWB01)',
      locationLabel: 'Office Location',
    },
  };
  const currentConfig = formConfig[loginType];

  return (
    <div className="font-sans bg-gray-50 min-h-screen w-full">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 p-4">
        <div className="container mx-auto text-center"> {/* Centered heading */}
          <h1 className="text-xl font-bold text-gray-800">Smart Tourist Safety System</h1>
        </div>
      </header>

      <main className="container mx-auto p-4 sm:p-8">
        {/* --- HERO & FEATURES SECTIONS (No changes) --- */}
        <section className="text-center py-12 sm:py-16">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight">Advanced Monitoring & Rapid Response</h2>
          <p className="mt-4 max-w-2xl mx-auto text-base sm:text-lg text-gray-600">A unified platform for ensuring tourist safety through real-time tracking, instant alerts, and streamlined incident management.</p>
        </section>
        <section className="py-12 sm:py-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
           <K hd="Real-Time Geofencing" tp="map" txt="Monitor tourist clusters within a 20km radius and receive alerts for any deviations from safe zones." />
           <K hd="Instant Panic Alerts" tp="alert" txt="Receive high-priority SOS signals with live locations, enabling immediate dispatch and support." />
           <K hd="Incident Reporting" tp="report" txt="Manage and respond to tourist-reported incidents, complete with images and precise coordinates." />
          </div>
        </section>
        {/* --- END HERO & FEATURES --- */}

        {/* Login Form Section */}
        <section className="py-12 sm:py-16">
          <div className="max-w-xl mx-auto bg-white p-8 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold text-center text-gray-900">Official Login</h2>
            
            {/* --- Animated Tab Switcher --- */}
            <div className="mt-6 p-1 bg-gray-200 rounded-lg flex relative">
              <div 
                className="absolute top-1 left-1 bottom-1 bg-white rounded-md shadow-sm transition-transform duration-300 ease-in-out"
                style={{
                  width: 'calc(50% - 4px)',
                  transform: loginType === 'police' ? 'translateX(0%)' : 'translateX(100%)',
                }}
              />
              <button onClick={() => handleTabChange('police')} className="flex-1 p-2 text-sm font-semibold rounded-md z-10 focus:outline-none">Police</button>
              <button onClick={() => handleTabChange('tourism')} className="flex-1 p-2 text-sm font-semibold rounded-md z-10 focus:outline-none">Tourism Dept.</button>
            </div>
            {/* --- End Tab Switcher --- */}

            <form onSubmit={handleLogin} className="mt-8 space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">{currentConfig.nameLabel}</label>
                <input id="name" name="name" type="text" required value={formData.name} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={currentConfig.namePlaceholder} />
              </div>
              <div>
                <label htmlFor="id" className="block text-sm font-medium text-gray-700">{currentConfig.idLabel}</label>
                <input id="id" name="id" type="text" required value={formData.id} onChange={handleInputChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={currentConfig.idPlaceholder} />
              </div>
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700">{currentConfig.locationLabel}</label>
                <select 
                  id="location" 
                  name="location" 
                  required 
                  value={formData.location} 
                  onChange={handleInputChange} 
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                >
                  {LOCATION_OPTIONS[loginType].map(loc => (
                    <option key={loc} value={loc}>{loc}</option>
                  ))}
                </select>
              </div>
              
              {error && <p className="text-sm text-red-600 text-center">{error}</p>}
              
              <div>
                <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors">Access Dashboard</button>
              </div>
            </form>
          </div>
        </section>
      </main>
    </div>
  );
}

